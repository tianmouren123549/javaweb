package com.red.workone;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/login")
public class Login extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String jspPath = "login.jsp";
        RequestDispatcher rd = request.getRequestDispatcher(jspPath);
        rd.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        // 获取表单参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 简单验证逻辑
        if ("admin".equals(username) && "password".equals(password)) {
            // 登录成功，转发到 home.jsp
            RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
            rd.forward(request, response);
        } else {
            // 登录失败，转发回 login.jsp
            request.setAttribute("errorMessage", "错了,再猜猜.");
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            rd.forward(request, response);
        }
    }
}

