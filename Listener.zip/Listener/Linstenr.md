# Listener练习

## 要求

1. **实现一个 ServletRequestListener 来记录每个 HTTP 请求的详细信息。**
2. **记录的信息应包括但不限于：**

* **请求时间**
* **客户端 IP 地址**
* **请求方法（GET, POST 等）**
* **请求 URI**
* **查询字符串（如果有）**
* **User-Agent**
* **请求处理时间（从请求开始到结束的时间）**

3. **在请求开始时记录开始时间，在请求结束时计算处理时间。**
4. **使用适当的日志格式，确保日志易于阅读和分析。**
5. **实现一个简单的测试 Servlet，用于验证日志记录功能。**
6. **提供简要说明，解释你的实现方式和任何需要注意的事**

## 主要部分

### 用途

本案例用于监听发起的请求并记录HTTP请求信息

### 实现

由于是针对HTTP请求，在请求发起时，该类会调用requestInitialized类，在这个类中记录：

- 发起请求起始的时间戳startTime
- 客户端IP地址-customer
- 获取请求的方法-method
- 请求的URI-path
- 请求字符串-quit
- User-Agent-usetAgent

以上信息并记录入列表list中，并将起始时间戳和列表作为请求属性传递给requestDestroyed。

### requestDestroyed

记录结束的时间戳-endTime，并与传递过来的起始时间戳计算出请求时间-payTime，并添加进传递过来的列表中，然后写入data.csv文件完成记录

